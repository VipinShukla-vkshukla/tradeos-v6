# TradeOS v6 — Brain Engine v2
## Complete Setup & Reference Guide

---

## File Structure

Place the entire `brain/` folder under `backend/` as a sibling to your
existing `ai/`, `compute/`, `signals/` folders:

```
backend/
├── ai/                          ← existing
├── compute/                     ← existing
├── signals/                     ← existing
├── brain/                       ← NEW (drop all files here)
│   ├── __init__.py
│   ├── brain_engine.py          ← orchestrator (main entry point)
│   ├── brain_prompt.py          ← master LLM persona (trading + quant expertise)
│   ├── data_aggregator.py       ← SELECT * everywhere, forward returns, outcome proxy
│   ├── quant_analyzer.py        ← 12 analysis types, all numeric + categorical fields
│   ├── backtester_and_change_manager.py  ← validation + proposal lifecycle + CLI + Telegram
│   ├── llm_synthesizer.py       ← full-data LLM synthesis via your ai_router
│   ├── script_scanner.py        ← auto-discovers hardcoded values in ALL scripts
│   ├── performance_tracker.py   ← daily/weekly/monthly metrics to performance_metrics table
│   ├── position_manager.py      ← Telegram buttons + open/close positions
│   ├── scheduler.yaml           ← full schedule config (all jobs)
│   ├── scheduler_yaml.py        ← YAML scheduler runner (APScheduler)
│   ├── schema.sql               ← run ONCE in Supabase
│   └── README.md                ← this file
├── config.py                    ← existing
├── run_pipeline.py              ← existing (no changes needed)
└── .env                         ← existing
```

> **Note:** `backtester_and_change_manager.py` is a single file.
> In your codebase, import from it as:
> ```python
> from brain.backtester_and_change_manager import run_backtests, save_proposals, ...
> ```

---

## First Run — Step by Step

### Step 1: Run Schema in Supabase
Open Supabase → SQL Editor → paste contents of `schema.sql` → Run.
This creates 6 new tables and inserts 15 new `system_config` keys.
Verify with: `SELECT key FROM system_config WHERE key LIKE 'brain_%';`
Expected: 6 brain config rows.

### Step 2: Install Dependencies
```bash
pip install apscheduler pyyaml pandas numpy scipy loguru
# APScheduler for scheduler_yaml.py
# All others likely already installed
```

### Step 3: Dry Run (safe — zero writes)
```bash
cd backend
python -m brain.brain_engine --mode dry --days 60
```
Expected output:
- Lists tables loaded and row counts
- Shows signal count and outcome coverage %
- Prints proposals (without saving)
- No DB writes, no Telegram

### Step 4: Script Scan (safe — only writes to brain_script_registry)
```bash
python -m brain.brain_engine --mode scan
```
Expected: scans all .py files, prints report of hardcoded values found.
Check `brain_script_registry` table in Supabase — should have rows for each script.

### Step 5: Quant-Only Run (writes proposals, no LLM)
```bash
python -m brain.brain_engine --mode quant
```
Check `brain_proposals` table. Review first proposals manually.
```bash
python -m brain.backtester_and_change_manager list
```

### Step 6: Approve One Proposal (test lineage)
```bash
python -m brain.backtester_and_change_manager approve <id>
python -m brain.backtester_and_change_manager history
```
Verify `config_change_log` has a row with `changed_by='manual'` and old/new values.

### Step 7: Full Run (LLM synthesis enabled)
```bash
python -m brain.brain_engine --mode full
```
This uses your active `ai_provider` from `system_config` (currently deepseek).

### Step 8: Start Scheduler
```bash
# Option A — APScheduler (recommended)
python -m brain.scheduler_yaml

# Option B — View crontab equivalent
python -m brain.scheduler_yaml --cron

# Option C — Run a specific job now
python -m brain.scheduler_yaml --run brain_full_weekly
```

### Step 9: Integrate Position Manager into send_alerts.py
See the integration block at the bottom of `position_manager.py`.
Two additions to your existing code:
1. `build_signal_keyboard()` call when sending signal alerts
2. Telegram webhook endpoint to handle button callbacks

---

## The One Code Change Required in screen_stocks.py

Move `REGIME_ENGINE_WEIGHTS` from hardcoded to `cfg()`:

```python
# In screen_stocks.py — replace your hardcoded dict with:
import json
from config import cfg

def get_regime_engine_weights() -> dict:
    raw = cfg("regime_engine_weights", "{}")
    try:
        return json.loads(raw)
    except Exception:
        return {}  # equal weights fallback

# In your aggregation loop:
weights = get_regime_engine_weights()
regime_weights  = weights.get(current_regime, {})
engine_multiplier = regime_weights.get(engine_name, 1.0)
```

This is the ONLY required change to any existing script for Phase 1.
Everything else (thresholds, MSL weights, lesson thresholds) is already
read via `cfg()` or will be migrated by the brain's SCRIPT_PATCH proposals.

---

## Adding a New Script or Table (Case B from v1 — now 3 minutes, not 3 hours)

The brain auto-discovers everything. You do nothing.

**New table written by a new script:**
1. The script scanner will detect it next Saturday (scheduled scan)
2. Or trigger immediately: `python -m brain.brain_engine --mode scan`
3. The brain_script_registry will show the new script with tables_read/written
4. The LLM synthesizer automatically includes the new table data in its analysis
5. The quant_analyzer will run correlations on any numeric fields in the new table

**There is no step 4.** The system is plug-and-play.

**For the brain to write proposals about a new table's data:**
The quant_analyzer's categorical and numeric analyses run on `signals` (signal_log).
If the new table enriches signal_log with new fields (like `sector_rotation_score`),
those fields automatically get correlated with forward returns.

If the new table is entirely separate (e.g., `options_data`), add it to
`data_aggregator.py`'s return dict in 3 lines and the LLM will see it.

---

## How the Brain Modifies Scripts (SCRIPT_PATCH)

**Phase 1 (current — `brain_script_patching_enabled=false`):**
- Brain detects hardcoded values via `script_scanner.py`
- Generates `SCRIPT_PATCH` proposals with unified diffs
- You review them in the proposal queue
- You apply manually: copy the diff, apply with `patch` or your editor
- Mark as applied via dashboard or CLI

**Phase 2 (enable when ready — `brain_script_patching_enabled=true`):**
- Brain auto-applies cfg() migrations to scripts
- Full git integration: each patch = one commit with proposal ID in message
- Rollback = `git revert` + restore from `script_change_log.backup_content`
- `brain_script_auto_patch=false` keeps it manual-approval even when patching is enabled

**To enable Phase 2:**
```sql
UPDATE system_config SET value='true' WHERE key='brain_script_patching_enabled';
```

---

## Performance Measurement — What "Better" Means

**Daily** (horizon: D+5):
- Win rate of signals from 7-9 calendar days ago
- Score→Return Pearson r at D+5
- Signal count by type

**Weekly** (horizon: D+10, runs every Sunday):
- Win rate at D+10 (primary decision horizon)
- Engine leaderboard with delta vs previous week
- Regime accuracy
- Brain impact: proposals applied this week + win rate delta
- AI conviction accuracy (HIGH vs MEDIUM vs LOW)

**Monthly** (horizon: D+20, runs on month-end):
- Win rate at D+20 (complete picture)
- Score correlation trend (is final_score improving over time?)
- Cumulative P&L from closed_positions (actual trades)
- Before/After for each applied brain proposal
- AI provider comparison

All metrics stored in `performance_metrics` table.
Weekly Telegram digest sent every Sunday at 20:00 IST.

---

## CLI Reference

```bash
# Brain runs
python -m brain.brain_engine --mode dry      # analysis only, zero writes
python -m brain.brain_engine --mode scan     # script scan only
python -m brain.brain_engine --mode quant    # quant + proposals, no LLM
python -m brain.brain_engine --mode full     # everything
python -m brain.brain_engine --mode full --days 60   # override lookback

# Proposal management
python -m brain.backtester_and_change_manager list
python -m brain.backtester_and_change_manager approve 42
python -m brain.backtester_and_change_manager reject 42
python -m brain.backtester_and_change_manager rollback 42
python -m brain.backtester_and_change_manager history
python -m brain.backtester_and_change_manager history --n 50

# Scheduler
python -m brain.scheduler_yaml               # start blocking scheduler
python -m brain.scheduler_yaml --list        # list all jobs + schedules
python -m brain.scheduler_yaml --cron        # print crontab equivalent
python -m brain.scheduler_yaml --run <job>   # run one job immediately

# Performance
python -c "from brain.performance_tracker import run_performance_tracking; run_performance_tracking()"
python -c "from brain.performance_tracker import send_weekly_telegram_summary; send_weekly_telegram_summary()"
```

---

## Safety Guarantees (Hardcoded — Cannot Be Overridden)

| Guard | Value | Where Enforced |
|---|---|---|
| Max threshold change per cycle | ±30% | `backtester_and_change_manager.py` |
| Min signals for a statistical finding | 15 | `quant_analyzer.py` |
| Min backtest cohort | 10 | `backtester_and_change_manager.py` |
| High-impact flag (>50% signal reduction) | always manual | `backtester_and_change_manager.py` |
| SCRIPT_PATCH, CODE_SUGGESTION, INSIGHT | never auto-apply | `backtester_and_change_manager.py` |
| Engine weight min/max | 0.3x – 2.0x | `backtester_and_change_manager.py` |
| LLM confidence cap vs sample size | n<20→0.60, n<50→0.75, n<100→0.85 | `brain_prompt.py` |
| Master kill switch | halts everything | `brain_engine.py` |

---

## Dashboard Implementation Priority

1. **Tab 5 — Data Management** (week 1): Config editor, positions CRUD
2. **Tab 2 — Positions** (week 1): Open/closed positions with P&L
3. **Tab 4 — Brain Queue** (week 2): Proposal approval, config audit log
4. **Tab 1 — Performance** (week 2): Win rate trends, engine leaderboard
5. **Tab 3 — AI Intelligence** (week 3): Conviction accuracy, market intel
6. **Tab 4 — Before/After** (month 2): Needs 4+ weeks of applied proposals

Full specification in `DASHBOARD_SPEC.md`.
